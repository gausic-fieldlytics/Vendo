(function () {
    'use strict';
    angular.module('app.table').constant('autoincmasterModel', {
        'add': {
           "prefix":"prefix",
"value":"value",
"length":"length",
"keyword":"keyword",
"status":"status"
        },
        'edit': {
            "id": "id",
           "prefix":"prefix",
"value":"value",
"length":"length",
"keyword":"keyword",
"status":"status"
        },
        'delete': {
            "id": "id"
        },
        'searchbyid': {
            "id": "id"
        },
        'searchall': {           
        },
        'ddlist': {
            
        }
    });
})();
