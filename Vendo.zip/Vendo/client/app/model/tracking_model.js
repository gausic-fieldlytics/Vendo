(function () {
    'use strict';
    angular.module('app.table').constant('trackingModel', {
        'onlinedriver': {
        },
        'history': {
           
            "fromdate": "fromdate",
            "todate": "todate"
        },
        'livetrack': {
            "companyid": "companyid",
        },

    });
})();
