﻿(function () {

    angular
      .module('app.table')

      



})();